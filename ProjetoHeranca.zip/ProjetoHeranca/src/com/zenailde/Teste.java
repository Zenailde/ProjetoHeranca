
package com.zenailde;


public class Teste {

    public static void main(String[] args) {
      EmpregadoBaseMaisComissao empregado = new EmpregadoBaseMaisComissao(
            "Zenailde", "Silva", "123.456.789-00", 10000, .06, 1800.00);
        
         System.out.println(
            "Informação do empregado obtida por métodos get: ");
        System.out.printf(
            "%s %s\n", "Nome é", empregado.getNome()
        );
        System.out.printf(
            "%s %s\n", "Sobrenome é", empregado.getSobrenome()
        );
        System.out.printf(
            "%s %s\n", "CPF é", empregado.getCpf()
        );
        System.out.printf(
            "%s %s\n", "Vendas brutas é", empregado.getVendasBrutas()
        );
        System.out.printf(
            "%s %s\n", "Taxa de comissão é", empregado.getTaxaDeComissao()
        );
        
         System.out.printf(
            "%s %s\n", "Seu salario Base é", empregado.getSalarioBase()
        );
        
        System.out.printf(
            "%s %s\n", "Seus rendimentos são de", empregado.rendimentos()
        );

        empregado.setVendasBrutas(500.00);
        empregado.setTaxaDeComissao(.1);
        empregado.setSalarioBase(1800.00);

        System.out.printf(
            "\n%s:\n\n%s\n", 
            "Informação atualizada obtida via toString", empregado
        );

    } 
    
    
}
