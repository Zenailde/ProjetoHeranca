
package com.zenailde;

public class EmpregadoComissao extends Empregado {
    
    private double vendasBrutas;
    private double taxaDeComissao;


    
    public EmpregadoComissao(String nome, String sobrenome, String cpf,double vendasBrutas, double taxaDeComissao) {
        super(nome, sobrenome, cpf);
        this.vendasBrutas = vendasBrutas;
        this.taxaDeComissao = taxaDeComissao;
    }

    public double getVendasBrutas() {
        return vendasBrutas;
    }



    public double getTaxaDeComissao() {
        return taxaDeComissao;
    }

    /**
     *
     * @param vendasBrutas
     */
    public void setVendasBrutas(double vendasBrutas) {
        if (vendasBrutas >= 0.0)
            this.vendasBrutas = vendasBrutas;
        else
            throw new IllegalArgumentException(
                "Vendas Brutas devem ser >= 0.0"
            );
    }
    
     public void setTaxaDeComissao(double taxaDeComissao) {
        if (taxaDeComissao > 0.0 && taxaDeComissao < 1.0)
            this.taxaDeComissao = taxaDeComissao;
        else
            throw new IllegalArgumentException(
                "A taxa de comissão deve ser > 0.0 e < 1.0"
            );
    }
     
     public double rendimentos() {
        return taxaDeComissao * vendasBrutas;
    }

    // retorna a representação em String do objeto
    @Override // indica que esse objeto sobrescreve o método da superclasse
    public String toString() {
        //return String.format("%s: %s %s\n%s: %s\n%s: %.2f\n%s: %.2f", 
           return String.format("%s: \n%s: %.2f\n%s: %.2f", 
            super.toString(),
            "Vendas Brutas", vendasBrutas,
            "Taxa de Comissão", taxaDeComissao);
    }
}
    
    


